<!-- End of page content -->
</main>
<footer class="footer bg-dark text-white">
    <div class="container-fluid">
        <div class="row">
            <div class="col text-center">
                <p class="mb-0">
                    ©
                    <?= date('Y') ?> All rights reserved. Developed By <a href="https://devtarak.github.io/"
                        target="_blank" class="decoration-none">Tarak Rahman</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<script src="<?= base_url('include/admin_asset/js/main.js') ?>" type="text/javascript" defer></script>
<script src="<?= base_url('include/admin_asset/bootstrap/bootstrap.bundle.min.js') ?>" type="text/javascript"
    defer></script>
</body>

</html>